#include<stdio.h>

void main()
{
	int m,n;
	printf("Enter size of first array: ");
	scanf("%d",&m);
	printf("Enter size of second array: ");
	scanf("%d",&n);

	int x[m],y[n],tmp[m+n],i,j,t;

	printf("Enter elements of first array\n");
	for(i=0;i<m;i++)
		scanf("%d",&x[i]);

	printf("Enter elements of second array\n");
	for(i=0;i<n;i++)
		scanf("%d",&y[i]);

	for(i=0;i<m;i++)
	{
		tmp[i]=x[i];
	}
	for(j=0;j<n;j++,i++)
		tmp[i]=y[j];

	for(i=0;i<m+n;i++)
	{
		for(j=0;j<(m+n)-i-1;j++)
		{
		if(tmp[j]>tmp[j+1])
		{
			t = tmp[j];
			tmp[j]=tmp[j+1];
			tmp[j+1]=t;
		}
		}
	}

	for(i=0;i<m;i++)
		x[i]=tmp[i];
	for(j=0;j<n;j++,i++)
		y[j]=tmp[i];

	printf("X[] = { ");
	for(i=0;i<m;i++)
		printf("%d ",x[i]);
	printf("}\n");

	printf("Y[] = { ");
	for(i=0;i<n;i++)
		printf("%d ",y[i]);	
	printf("}\n");
}