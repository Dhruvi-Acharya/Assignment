#include<iostream>
using namespace std;

class Employee
{
	public:
	double salary;
	int no_hours_per_day;

	void getInfo() //function for geeting salary and working hours
	{
		cout << "Enter the salary of employee: ";
		cin >> salary;
		cout << "Enter the number of hours: ";
		cin >> no_hours_per_day;
	}
	void AddSal() // add amount if salary < 500
	{
		if(salary < 500)
			salary += 10;
	}
	void AddWork() // add amount if hours > 6
	{
		if(no_hours_per_day > 6)
			salary += 5;
	}
};

int main()
{
	Employee e;
	e.getInfo(); //getting information
	e.AddSal(); 
	e.AddWork();
	cout<<"Employee final salary is: "<<e.salary;
	return 0;
}