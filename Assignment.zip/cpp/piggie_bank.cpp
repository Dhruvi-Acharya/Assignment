#include<iostream>
using namespace std;

class AddAmount
{
	int amount = 50;
public:
	AddAmount()
	{
		amount=amount;
	}
	AddAmount(int addedAmount)
	{
		amount = amount + addedAmount;
	}
	void final_amount()
	{
		cout<<amount<<endl;
	}
};

int main()
{
	int moreamount;
	AddAmount a1;
	cout<<"initial amount: ";
	a1.final_amount();
	
	printf("Enter amount you want to add: ");
	cin>>moreamount;

	AddAmount a2(moreamount);

	cout<<"Final Amount: ";
	a2.final_amount();
}