#include<iostream>
using namespace std;

class Matrix
{
	int no_row,no_col;
	int a[10][10];
public:
	Matrix(int row,int column)
	{
		no_row = row;
		no_col = column;
	}

	int get_row()
	{
		return no_row;
	}

	int get_col()
	{
		return no_col;
	}

	void set_element()
	{
		for(int i=0;i<no_row;i++)
		{
			for(int j=0;j<no_col;j++)
			{
				scanf("%d",&a[i][j]);
			}
		}
	}

	void print_matrix()
	{
		for(int i=0;i<no_row;i++)
		{
			for(int j=0;j<no_col;j++)
			{
				cout<<a[i][j]<<" ";
				//printf("%d ",a[i][j]);
			}
			cout<<endl;
			//printf("\n");
		}	
	}

	Matrix addition(Matrix x,Matrix y)
	{
		Matrix tmp(no_row,no_col);

		for(int i=0;i<no_row;i++)
		{
			for(int j=0;j<no_col;j++)
			{
				tmp.a[i][j]=x.a[i][j]+y.a[i][j];
			}
		}

		return tmp;
	}

	Matrix multiplication(Matrix x,Matrix y)
	{
		Matrix tmp(x.no_row,y.no_col);

		for(int i=0;i<x.no_row;i++)
		{
			for(int j=0;j<y.no_col;j++)
			{
				int s=0;
				for(int k=0;k<x.no_col;k++)
				{
					tmp.a[i][j] = tmp.a[i][j] + (x.a[i][k]*y.a[k][j]);
				}
			}
		}

		return tmp;
	}
};

int main()
{
	int r1,r2,c1,c2,r3,c3;

	cout<<"Enter no of rows for first matrix: ";
	cin>>r1;
	cout<<"Enter no of columns for first matrix: ";
	cin>>c1;

	Matrix m1(r1,c1);
	cout<<"Enter elements of first matrix: ";
	m1.set_element();

	cout<<"Enter no of rows for second matrix: ";
	cin>>r2;

	cout<<"Enter no of columns for second matrix: ";
	cin>>c2;

	Matrix m2(r2,c2);
	cout<<"Enter elements of second matrix"<<endl;
	m2.set_element();

	cout<<"First matrix:"<<endl;
	m1.print_matrix();

	cout<<"Second Matrix:"<<endl;
	m2.print_matrix();

	r3= m1.get_row();
	c3=m1.get_col();

    Matrix m3(r3,c3);
    m3= m3.addition(m1,m2);
    cout<<"Addition of two matrices is\n";
    m3.print_matrix();

    Matrix m4(m1.get_row(),m2.get_col());
    m4=m4.multiplication(m1,m2);
    
    cout<<"Multiplication of two matrices is: "<<endl;
    m4.print_matrix();

	return 0;
}