/*
Write a menu driven program that depicts the working of a library.
The menu options should be:
1. Add book information
2. Display book information
3. List all books of given author
4. List the titke of specified book
5. List the count of books in the library
6. List the books in the order of accession number
7. Exit
Create a structure called libraary to hold accession number, title of book, author name, price of the book, and flag indicating wheather the book is issued or not.
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct library{ //structure of library
  int accession_no,flag;
  float price;
  char title[20],author_name[20];
};

void sortBookAccession(struct library [],int); //function to sort book by accession number

void main()
{
  struct library l[10];
  int choice,i=0,count=0,tmp;
  char auName[20],bTitle[20];

  
  do{
    printf("\n\t\tMenu\n");
    printf("-------------------------------------\n");
    printf("\n1.Add book information\n2.Display book information\n3.List all books of given author\n4.List the title of specified book\n5.List the count of books in the library\n6.List the books in the order of accession number\n7.Exit\n");
    printf("-------------------------------------\n");
    printf("Enter your choice: ");
    scanf("%d",&choice);

    switch(choice)
    {
      case 1:
      printf("Enter Accession number: ");
      scanf("%d",&l[i].accession_no);
      printf("Enter title of a book: ");
      scanf("\n");
      scanf("%[^\n]c",l[i].title);
      printf("Enter Author name: ");
      scanf("\n");
      scanf("%[^\n]c",l[i].author_name);
      printf("Enter price: ");
      scanf("%f",&l[i].price);
      printf("Book issued? 1- yes, 0 - no: ");
      scanf("%d",&l[i].flag);
      printf("\nBook added successfully\n");
      i++;
      break;
      case 2:
      printf("\n-------------------------------------\n");
      printf("\t Details of all Books:\n");
      printf("-------------------------------------\n");
      if(i==0)
        printf("Library is Empty\n");
      else
      {
        printf("\n%-20s%-20s%-20s%-20s%-20s\n","Accession Number","Title","Author","Price","Book issued? 1-yes 0-no\n");
        for(int j=0;j<i;j++)
        {
          printf("%-20d%-20s%-20s%-20.2f%-20d\n\n",l[j].accession_no,l[j].title,l[j].author_name,l[j].price,l[j].flag);
        }
      }
      break;

      case 3:
      if(i==0)
      {
        printf("\n Library is Empty\n");
      }
      else {
        printf("Enter Author name: ");
        scanf("\n");
        scanf("%[^\n]c",auName);
        tmp = 0;
        for(int j=0;j<i;j++)
        {
          if(strcmp(l[j].author_name,auName)==0)
          {
            tmp=1;
            printf("%s\n",l[j].title);
          }
        }
        if(tmp==0)
        {
          printf("\nThere is no book of given author\n");
        }
      }
      break;
      case 4:
      if(i==0)
      {
        printf("\n Library is Empty\n");
      }
      else {
        printf("Enter book title: ");
        scanf("\n");
        scanf("%[^\n]c",bTitle);
        tmp=0;
        printf("\n%-20s%-20s%-20s%-20s%-20s\n","Accession Number","Title","Author","Price","Book issued? 1-yes 0-no\n");
        for(int j=0;j<i;j++)
        {
          if(strcmp(l[j].title,bTitle)==0)
          {
            tmp=1;
            printf("%-20d%-20s%-20s%-20.2f%-20d\n\n",l[j].accession_no,l[j].title,l[j].author_name,l[j].price,l[j].flag);
          }
        }
        if(tmp==0)
        {
          printf("\n there is no book of given title\n");
        }
      }
      break;
      case 5:
      if(i==0)
      {
        printf("\n Library is Empty\n");
      }
      else {
        for(int j=0;j<i;j++)
          count++;
        printf("\nTotal number of books in library: %d\n",count);
      }
      break;
      case 6:
      if(i==0)
      {
        printf("\n Library is Empty\n");
      }
      else {
        sortBookAccession(l,i);
        printf("\n%-20s%-20s%-20s%-20s%-20s\n","Accession Number","Title","Author","Price","Book issued? 1-yes 0-no\n");
        for(int j=0;j<i;j++)
        {
          printf("%-20d%-20s%-20s%-20.2f%-20d\n\n",l[j].accession_no,l[j].title,l[j].author_name,l[j].price,l[j].flag);
        }
      }
      break;
      case 7:
      exit(0);
      default:
      printf("enter valid choice\n");
    }
  }while(choice!=7);
}

void sortBookAccession(struct library myLibrary[],int size) {
  int i, j, indexmin;
  struct library temp;
  for(i = 0; i<size; i++) {
    indexmin = i;  
    for(j = i+1; j<size; j++)
      if(myLibrary[j].accession_no < myLibrary[indexmin].accession_no)
        indexmin = j;
      temp = myLibrary[i];
      myLibrary[i] = myLibrary[indexmin];
      myLibrary[indexmin] = temp;
    }
  }