/*
Search and Sequence
Consider an integer array 'a' of size 10, where the value of the array elements are {1,5,4,8,9,2,0,6,11,7}
write a program to find whether the given elements exist in an array or not. If the elements exists in an array, display YES else NO.
to print a number following a sequence of elemets in an array i.e., 15489206117.
*/

#include<stdio.h>

void main()
{
	int a[10]={1,5,4,8,9,2,0,6,11,7};
	int i,search_element,flag=0;
	printf("Array Elements are:\n");
	for(i=0;i<10;i++)
		printf("%d ",a[i]);
	printf("\nEnter elemnt you want to search: ");
	scanf("%d",&search_element);
	for(i=0;i<10;i++)
	{
		if(a[i]==search_element)
			flag=1;
	}
	if(flag==0)
		printf("NO\n");
	else
		printf("YES\n");
	printf("Sequence of Elements:\n");
	for(i=0;i<10;i++)
		printf("%d",a[i]);
}