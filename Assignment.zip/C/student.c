/*
write a function that receives marks received by a student in 3 subjects and returns the total ane percentage of these marks.
call this function from main() and print the results in main().
*/

#include<stdio.h>

void funTotalPer(float,float,float,float *,float *,float); //function calculates total and percentage

void main()
{
	float m1,m2,m3,total,per,max;

	printf("Enter the marks of subject 1: ");
	scanf("%f",&m1);
	printf("Enter the marks of subject 2: ");
	scanf("%f",&m2);
	printf("Enter the marks of subject 3: ");
	scanf("%f",&m3);
	printf("What's the total marks(of 3 subjects combined): ");  
    scanf("%f", &max); 
	funTotalPer(m1,m2,m3,&total,&per,max);
	printf("Total is: %.2f\n",total);
	printf("Percentage is: %.2f\n",per);
}

void funTotalPer(float m1,float m2,float m3,float *total,float *per,float max)
{
	*total = m1+m2+m3;
	*per = ((m1+m2+m3)*100)/max;
}